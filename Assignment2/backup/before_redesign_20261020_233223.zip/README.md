# ENGI 9861 - Assignment 2, Part A

Open `assignment2.qpf` in Quartus Prime Lite 20.1. The project contains five
revisions. Select the component in **Project > Revisions**, then open the
corresponding `.bdf` file from **File > Open** or the project Files view.

| Revision / schematic | Inputs | Output |
| --- | --- | --- |
| `counter16.bdf` | CLK, CLR, LD, INC, DIN[15..0] | Q[15..0] |
| `counter12.bdf` | CLK, CLR, LD, INC, DIN[11..0] | Q[11..0] |
| `register8.bdf` | CLK, LD, DIN[7..0] | Q[7..0] |
| `register16.bdf` | CLK, LD, DIN[15..0] | Q[15..0] |
| `bus16_mux8.bdf` | D0[15..0] through D7[15..0], SEL[2..0] | Y[15..0] |

## Viewing and editing the circuits

All implementations are native, editable BDF schematics, including the child
circuits. There are no HDL black boxes. Matching wire names on a sheet are
electrically connected; vector and individual-bit names refer to the same bus.

The top-level counter and register schematics show all individual bit cells.
To inspect their gates, select a cell and use **Hierarchy > Descend** (or the
context-menu equivalent). Alternatively, open the child BDF directly:

- `counter_bit.bdf`: XOR increment logic, carry propagation, priority muxes,
  synchronous clear gate, and one D flip-flop.
- `register_bit.bdf`: feedback/load mux and one D flip-flop.
- `mux2_word.bdf`: sixteen parallel single-bit multiplexers.
- `mux2_bit.bdf`: NOT, two AND gates, and one OR gate.

The `.bsf` files are reusable symbols, including symbols for the five components
to place in the subsequent datapath assignment. Keep all BDF and BSF files
together when copying or submitting the project.

## Behavior

Counters update on the rising edge of CLK. All control inputs are active high:

| CLR | LD | INC | Action at rising edge |
| --- | --- | --- | --- |
| 1 | X | X | Q = 0 |
| 0 | 1 | X | Q = DIN |
| 0 | 0 | 1 | Q = Q + 1, wrapping modulo 2^width |
| 0 | 0 | 0 | Hold Q |

CLR is synchronous: it does not change the counter until a rising clock edge.
This follows the counter behavior table on PDF page 18 of the annotated digital
logic notes. Counter bit 0 has carry-in 1; each following carry-in is the AND
of all lower stored bits. Every flip-flop receives the same CLK (not a ripple
clock). Unused asynchronous preset/clear inputs are explicitly tied high.

Registers load DIN on a rising clock edge when LD=1, and otherwise hold their
value. They have no reset input. Load a known value before relying on their
contents in a simulation; power-up initialization is not part of their interface.

The BUS is combinational. Binary SEL selects the matching input: 000 -> D0,
001 -> D1, ..., 111 -> D7. Its three mux levels use SEL[0], SEL[1], SEL[2]
respectively. It has no clock, storage, or tri-state outputs.

## Verification completed

- Quartus Prime Lite 20.1.1 Analysis & Elaboration completed for all five
  revisions, with zero errors and zero warnings. Reports are in `output_files`.
- `tools/verify_schematics.py` recursively reads the actual BDF connections and
  evaluates their gate-level logic. It checks priority combinations, synchronous
  behavior, holding, carry propagation, overflow, register loading, and every
  bus input/bit/selection. Results are in `verification/logic_checks.txt`.

This check is not a ModelSim testbench simulation. No waveform screenshots,
FPGA fitting, timing analysis, programming, or hardware validation have been
performed. The assignment's simulation screenshots still need to be produced.

The default target is Cyclone V `5CGXFC7C7F23C8`, which is available in the
local installation. It is a compilation target, not a selected course board.
No physical pin assignments or timing constraints are supplied. Change the
target device if the course specifies a board.

## Rebuilding / rechecking

From this directory, using Python 3:

```powershell
python tools/build_schematics.py
python tools/verify_schematics.py
```

The generator reads the Quartus primitive symbol library installed under
`C:\intelFPGA_lite\20.1`. It overwrites all generated BDF/BSF and project files,
so do not rerun it after manual edits you want to retain.

For the native Quartus check, run the following once for each revision name
from the table above (without `.bdf`). Run revisions sequentially because they
share the project's compilation database:

```powershell
& 'C:\intelFPGA_lite\20.1\quartus\bin64\quartus_map.exe' assignment2 -c counter16 --analysis_and_elaboration
```

The project is intentionally stored in an English-only path; Quartus 20.1 failed
to open it under the original path containing Chinese characters.
